# Defaults for amxa-webfs initscript
# sourced by /etc/init.d/amxa-webfs
# installed at /etc/default/amxa-webfs by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
