?package(amxa-webfs):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="amxa-webfs" command="/usr/bin/amxa-webfs"
